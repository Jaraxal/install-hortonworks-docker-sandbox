#!/bin/bash

export CUR_DIR=`pwd`
export PROJ_DIR=`basename $CUR_DIR`

docker stop ${PROJ_DIR}
