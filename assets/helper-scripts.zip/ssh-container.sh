#!/bin/bash

ssh -p 2222 root@localhost
