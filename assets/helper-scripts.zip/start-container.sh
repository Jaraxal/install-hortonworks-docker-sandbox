#!/bin/bash

export CUR_DIR=`pwd`
export PROJ_DIR=`basename $CUR_DIR`

docker start ${PROJ_DIR}
